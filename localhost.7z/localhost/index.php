<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
<div class="recur">
<div class="add">
<form action="add.php" method="post">
    <input type="text" name="username" placeholder="username">
    <input type="text" name="surname" placeholder="surname">
    <input type="text" name="patronymic" placeholder="patronymic">
    <input type="text" name="contact" placeholder="contact">
    <input type="email" name="email" placeholder="email">
    <input type="submit" value="Добавить">

</form>
</div>
</div>

<script>
    function update(element){
        let formElements = document.querySelectorAll("#saveForm input[name]");
        for (let i = 0; i < formElements.length; i++) {
            formElements[i].value = element.dataset[formElements[i].name];
        }
    }
</script>

<?php
require_once ("connect.php");
$result=$connect->query("SELECT * FROM `user`" );
if(!$result){
    echo $connect->error;
    return;
}
while ($user=$result-> fetch_array()) {
    ?>
        <div class="user" onclick="update(this)"
             data-id="<?= $user['id'] ?>"
             data-surname="<?= $user['surname'] ?>"
             data-username="<?= $user['username'] ?>"
             data-patronymic="<?= $user['patronymic'] ?>"
             data-contact="<?= $user['contact'] ?>"
             data-email="<?= $user['email'] ?>">
            <div>
                <?= $user['surname'] ?>
                <?= $user['username'] ?>
                <?= $user['patronymic'] ?>
            </div>
            <div>
                <?= $user['contact'] ?>
            </div>
            <div>
                <?= $user['email'] ?>
            </div>
        </div>
<?php
}

?>
<div class="recur">
<div class="save">
<form action="save.php" method="post" id="saveForm">
    <input id="eid" hidden type="text" name="id" placeholder="id">
    <input id="eusername" type="text" name="username" placeholder="username">
    <input id="esurname" type="text" name="surname" placeholder="surname">
    <input id="epatronymic" type="text" name="patronymic" placeholder="patronymic">
    <input id="econtact" type="text" name="contact" placeholder="contact">
    <input id="eemail" type="email" name="email" placeholder="email">
<input type="submit" value="Сохранить">
</form>

</div>
</div>
</body>
</html>
