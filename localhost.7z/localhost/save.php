<?php
require_once ("connect.php");
$username=$_POST["username"];
$surname=$_POST["surname"];
$patronymic=$_POST["patronymic"];
$contact=$_POST["contact"];
$email=$_POST["email"];
$id=$_POST["id"];
$result = $connect->query("UPDATE `user` Set username='$username',surname='$surname',
                                patronymic='$patronymic',contact='$contact',email='$email'
                                WHERE id=$id");

header("Location: /index.php", TRUE,301);