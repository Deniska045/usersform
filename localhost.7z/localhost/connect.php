<?php
 $connect=new mysqli("localhost" , "root","","bd");
  if($connect->connect_errno !=0){
      die($connect->connect_error);
  }
