<?php
include "connect.php";
$username=$_POST["username"];
$surname=$_POST["surname"];
$patronymic=$_POST["patronymic"];
$contact=$_POST["contact"];
$email=$_POST["email"];

$result=$connect->query("INSERT INTO `user` (`username`,`surname`,`patronymic`,`contact`,`email`) 
                                    values ('$username','$surname','$patronymic','$contact','$email')" );
if(!$result){
    echo $connect->error;
}
header("Location: /index.php", TRUE,301);
